"""Build a six-page report from a complete, verified evidence directory."""

import argparse
from pathlib import Path

from PIL import Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (Image as PDFImage, PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle)
from xml.sax.saxutils import escape

from collect_results import HERE, load
from make_figures import MODELS, METHODS, plot_results

NAVY = colors.HexColor("#183752")
PALE = colors.HexColor("#ebf3f8")


def number(row, field, digits):
    return f"{float(row[field+'_mean']):.{digits}f} ± {float(row[field+'_sd']):.{digits}f}"


def build(root, contribution, output):
    rows = plot_results(root)  # Raises if any of the 64 real runs is missing.
    audit = load(HERE / "track3_preflight.json")
    selection = load(root / "validation_selection.json")["choices"]
    full = [r for r in rows if r["experiment"] != "08"]
    lookup = {(r["model"], r["experiment"]): r for r in full}
    w, h = A4
    width = w - 94
    story = []
    body = ParagraphStyle("body", fontName="Helvetica", fontSize=9.7, leading=14, textColor=NAVY)
    title = ParagraphStyle("title", parent=body, fontName="Helvetica-Bold", fontSize=19, leading=23,
                           spaceAfter=12)
    caption = ParagraphStyle("caption", parent=body, fontSize=8.3, leading=11)

    def para(text, style=body):
        story.append(Paragraph(escape(text), style))
        story.append(Spacer(1, 7))

    def page(heading):
        if story:
            story.append(PageBreak())
        para(heading, title)

    def table(data, widths=None):
        t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PALE]),
        ]))
        story.extend([t, Spacer(1, 12)])

    def figure(name, caption_text):
        path = root / "figures" / name
        with Image.open(path) as image:
            ratio = image.width / image.height
        fw = min(width, 296 * ratio)
        story.append(PDFImage(str(path), width=fw, height=fw/ratio))
        para(caption_text, caption)

    page("Urdu sentiment: fine-tuning at lower cost")
    para("Advanced Generative AI Assignment 3 | Track 3 | Group 3 | Seeds 3 and 103")
    para("Two pretrained encoders classify Positive, Negative and Objective tweets. The pinned author TSV is read in its original character order; the legacy Hub loader would reverse the text. We remove URLs and user mentions, map Arabic yeh and kaf to Urdu forms, normalize whitespace, and remove invalid, duplicate and conflicting-label rows.")
    table([["Split", "Total", "Positive", "Negative", "Objective"]] + [
        [key.title(), val["count"], *[val["labels"][k] for k in ("Positive", "Negative", "Objective")]]
        for key, val in audit["splits"].items()])
    table([
        ["Setting", "Value"],
        ["Encoders", "XLM-R base and MuRIL base cased"],
        ["Data", "996 cleaned rows; fixed stratified 70/15/15 with seed 3"],
        ["Training", "3 epochs; effective batch 16; final epoch; T4 FP16"],
        ["Learning rates", "Full FT: 2e-5; PEFT: 2e-4; linear schedule"],
        ["Sequence length", "43; larger training p95; dynamic padding"],
        ["LoRA / QLoRA", "Query/value, alpha 16; QLoRA NF4 and double quant."],
        ["IA3", "Key/value with or without FFN output projection"],
        ["Optimizer", "AdamW; QLoRA compares 32-bit bnb paged/unpaged"],
    ])
    data = [["Tokenizer", "Fertility", "p95", "Truncated", "UNK rate"]]
    for model, r in audit["tokenizers"]["models"].items():
        data.append(["MuRIL" if "muril" in model else "XLM-R", f"{r['fertility']:.3f}",
                     r["p95_nearest_rank"], f"{r['truncation_rate']:.2%}", f"{r['unknown_rate']:.3%}"])
    table(data)
    para("Tokenizer measurements use the same training texts. Fertility and UNK exclude special tokens; length and truncation include them. Memory is peak PyTorch CUDA allocation, measured over training only.")

    headings = ["Model / run", "Method", "F1", "Accuracy", "Sec.", "MiB", "Trainable"]

    def metrics_table(population, scarcity=False):
        values = [headings]
        for row in population:
            tag = f"{float(row['fraction']):.0%}/{row['effective_experiment']}" if scarcity else row["experiment"]
            values.append([MODELS[row["model"]] + " " + tag, METHODS[row["method"]],
                           number(row, "macro_f1", 3), number(row, "accuracy", 3),
                           number(row, "train_seconds", 1), number(row, "peak_mib", 0),
                           number(row, "trainable_params", 0)])
        table(values, [90, 58, 69, 69, 67, 66, 82])

    page("Full-data comparison")
    para("Held-out accuracy and macro-F1; all metrics are mean ± sample SD for seeds 3 and 103. MiB is allocated GPU memory, not total memory reserved.")
    metrics_table(full)
    para("01 Full FT; 02/03 LoRA rank 8/16; 04 adds FFN placement; 05/06 QLoRA paging on/off; 07a/07b IA3 attention only/attention + FFN.", caption)

    page("Reduced-data comparison")
    para("For each encoder and method, the highest mean validation macro-F1 chose one configuration. The row tag shows the data fraction and selected full-data configuration. Its 100% value comes from page 2.")
    metrics_table([r for r in rows if r["experiment"] == "08"], scarcity=True)
    para("The two seeds use paired, nested 25% and 50% subsets. Variation includes subset composition on the reduced runs.", caption)

    page("Rank and GPU memory")
    figure("rank.png", "Figure 1. LoRA rank comparison at fixed alpha=16, so the update scaling also changes.")
    figure("pareto_memory.png", "Figure 2. Macro-F1 versus peak GPU allocation for all full-data configurations. X/M identify XLM-R/MuRIL.")

    page("Time and label scarcity")
    figure("pareto_time.png", "Figure 3. Macro-F1 versus synchronized training time for all full-data configurations.")
    figure("scarcity.png", "Figure 4. Label scarcity for the validation-selected configurations, compared with their own full-data runs.")

    page("Tokenizer comparison and discussion")
    figure("fertility.png", "Figure 5. Fertility and macro-F1 for each method's selected configuration on the two encoders.")
    for model, label in MODELS.items():
        f = lambda exp: float(lookup[(model, exp)]["macro_f1_mean"])
        m = lambda exp: float(lookup[(model, exp)]["peak_mib_mean"])
        picked = selection[model]
        drops = {
            r["method"]: f(picked[r["method"]]) - float(r["macro_f1_mean"])
            for r in rows if r["model"] == model and r["experiment"] == "08" and float(r["fraction"]) == 0.25
        }
        robust = min(drops, key=drops.get)
        para(f"{label}: rank 16 minus rank 8 changes mean F1 by {f('03')-f('02'):+.3f}. Adding FFN changes LoRA by {f('04')-f('03'):+.3f} and IA3 by {f('07b')-f('07a'):+.3f}. Relative to rank-16 attention LoRA, paged QLoRA changes F1 by {f('05')-f('03'):+.3f} and peak allocation by {m('05')-m('03'):+.0f} MiB; this includes optimizer and precision differences. At 25% labels, {METHODS[robust]} has the smallest measured drop ({drops[robust]:+.3f}).")
    para("The two tokenizer points cannot separate pretraining, tokenization and encoder effects. Objective has only three held-out examples. Two seeds give a descriptive spread; they do not establish statistical significance.")
    para("Contribution: " + contribution)

    def foot(canvas, doc):
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(NAVY)
        canvas.drawString(47, 28, "Advanced GenAI | Assignment 3")
        canvas.drawRightString(w - 47, 28, str(doc.page))

    SimpleDocTemplate(str(output), pagesize=A4, topMargin=49, bottomMargin=45,
                      leftMargin=47, rightMargin=47, title="Assignment 3: Urdu sentiment").build(
                          story, onFirstPage=foot, onLaterPages=foot)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence", type=Path)
    parser.add_argument("--contribution", required=True, help="Truthful short member contribution statement")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    build(args.evidence, args.contribution, args.output)
